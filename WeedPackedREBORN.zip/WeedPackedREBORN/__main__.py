# {WPED REBORNED}
# Note: Don't change anything or you break it!!
# For help, fill out this form --> https://forms.gle/rokKarptieJYYieW7
# Finger Studios ©XXXX-2024

try:
    import admincmd, zipfile, os, io
    from tqdm import tqdm
except ModuleNotFoundError as e:
    print(f"MODULE NOT FOUND\nError: {e}\nPlease contact Finger Studios for more info. (Dont forget the error too)")
    input()
finally:
    print("Modules Loaded.")

class WPED:
    # Don't change anything
    def __init__(self, settings_file="settings.DAT"):
        self._mainextension = ".wpk"
        self._settings_file = settings_file
        self._packfolder = "packed"
        self._unpackfolder = "unpacked"
        self._version = "LA"
        self._load_settings()

    def _load_settings(self):
        try:
            with open(self._settings_file, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    key, value = line.strip().split('=')
                    if key == 'packfolder':
                        self._packfolder = value
                    elif key == 'unpackfolder':
                        self._unpackfolder = value
        except FileNotFoundError as e:
            print(f"Settings file not found: {e}")
        finally:
            print("Settings Loaded")

    def pack_files(self, output_file):
        print("Packing files... Please wait!")
        zip_filename = output_file + '.zip'
        
        # Count total files
        total_files = sum([len(files) for _, _, files in os.walk(self._packfolder)])
        
        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            with tqdm(total=total_files, unit='file') as pbar:
                for root, _, files in os.walk(self._packfolder):
                    for file in files:
                        file_path = os.path.join(root, file)
                        zipf.write(file_path, os.path.relpath(file_path, self._packfolder))
                        pbar.update(1)

        with open(zip_filename, 'rb') as f:
            data = f.read()
        
        obfuscated_data = self._obfuscate_data(data)

        with open(output_file + self._mainextension, 'wb') as f:
            f.write(self._version.encode('utf-8') + b'\n' + obfuscated_data)
        
        os.remove(zip_filename)
        print(f"Packed files into {output_file}.wpk")

    def unpack_files(self, packed_file):
        print("Unpacking files... Please wait!")
        try:
            with open(packed_file, 'rb') as f:
                version_line = f.readline().strip()
                self._file_version = version_line.decode('utf-8')
                data = f.read()
        except FileNotFoundError as e:
            print(f"File not found!\n{e}\nPlease contact Finger Studios for more info. (Don't forget the error too)")
            return

        deobfuscated_data = self._deobfuscate_data(data)

        temp_zip_filename = packed_file + '.zip'
        with open(temp_zip_filename, 'wb') as f:
            f.write(deobfuscated_data)

        with zipfile.ZipFile(temp_zip_filename, 'r') as zipf:
            file_list = zipf.namelist()
            with tqdm(total=len(file_list), unit='file') as pbar:
                for file in file_list:
                    zipf.extract(file, self._unpackfolder)
                    pbar.update(1)

        os.remove(temp_zip_filename)

        print("Unpacked files into the main unpack folder!")

    def view_contents(self, packed_file):
        print("Obtaining Info... Please wait!")
        try:
            with open(packed_file, 'rb') as f:
                version_line = f.readline().strip()
                self._file_version = version_line.decode('utf-8')
                data = f.read()
        except FileNotFoundError as e:
            print(f"File not found!\n{e}\nPlease contact Finger Studios for more info. (Don't forget the error too)")
            return None

        deobfuscated_data = self._deobfuscate_data(data)

        with zipfile.ZipFile(io.BytesIO(deobfuscated_data), 'r') as zipf:
            file_list = zipf.namelist()
            with tqdm(total=len(file_list), unit='file') as pbar:
                for _ in file_list:
                    pbar.update(1)
            return file_list

    def _obfuscate_data(self, data):
        return bytes(b ^ 0xAA for b in data)

    def _deobfuscate_data(self, data):
        return bytes(b ^ 0xAA for b in data)
    
    def get_file_version(self):
        return self._file_version

if __name__ == "__main__":
    print("WPED REBORN.\nFINGER STUDIOS\nVersion 1.0.2 | LA")
    
    wped = WPED()

    admincmd.prefix = ''

    @admincmd.addcmd()
    def info():
        '''Gives you information on how to use WPED Reborn.'''
        print("~INFO~")
        print("- How to pack\nTo pack, you must use the commmand 'pack'. To use it, It needs 1 arg (the file name).\nExample:\npack Example\npack is the name of the command, Example is just the name of the .wpk file!\nNote: You need to put all of the files you wanna pack into the packed folder.")
        print("- How to unpack\nTo unpack, You must need a .wpk file in the same folder as the script itself. Then, use the command 'unpack' and after put the name of the .wpk file splitted by a space.\nExample:\nunpack Example.wpk\nEvery file will be unpacked into the unpacked folder.")
        print("- How to view contents of a .wpk file\nTo see what a .wpk file has, you simply put the command view. Then, press space and put the name of the .wpk file you want to view.\nNote: the file must be in the same directory as the script itself.\n\nOther commands are self explanatory.")

    @admincmd.addcmd()
    def pack(filename: str):
        '''Packs files into a .wpk file. (1 ARG NEEDED: filename)'''
        wped.pack_files(filename)
    
    @admincmd.addcmd()
    def unpack(filename: str):
        '''Unpacks files from a .wpk file. (1 ARG NEEDED: filename)'''
        wped.unpack_files(filename)

    @admincmd.addcmd()
    def view(filename: str):
        '''Views the content of a .wpk file. (1 ARG NEEDED: filename)'''
        contents = wped.view_contents(filename)
        if contents:
            print(f"This file was made on version {wped.get_file_version()}")
            for c in contents:
                print(f"- {c}")

    @admincmd.addcmd()
    def changesetting(newpackedfolder: str, newunpackedfolder: str):
        '''Changes the settings. (the name of the packed and unpacked folder can be changed.) (2 ARGS NEEDED: newpackedfolder & newunpackedfolder)'''
        with open(wped._settings_file, 'w') as f:
            f.write("")
            f.write(f"packfolder={newpackedfolder}\nunpackfolder={newunpackedfolder}")
        wped._load_settings()

    admincmd.startercmds()
    print("Use 'help' command to get the list of commands!")
    admincmd.loop()