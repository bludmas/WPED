from tkinter import * 
from tkinter import messagebox 

prefix = "%"
cmds = {
    # 'help': CMDS.helpc,
    # 'errorinfo': CMDS.errorinfo
    # "msg": CMDS.msg
}

class CMDS:
    def __init__(self):
        self._vers = "1.0"

    @property
    def vers(self):
        return self._vers
    
    def helpc(optionalcmd=None) -> None:
        '''Shows commands and their descriptions'''
        if optionalcmd != None:
            import inspect
            for cmd, func in cmds.items():
                if cmd == optionalcmd:
                    args = inspect.signature(func)
                    print(f"Name: {cmd}\nDescription: {func.__doc__}\nArgs: {args}")
                    return
        print("Commands:")
        i = 1
        for cmd, func in cmds.items():
            print(f"{i}. {cmd} - {func.__doc__}")
            i += 1
    def errorinfo():
        '''Shows information about error codes'''
        print("**ERROR INFO**")
        print("1: Command not found.\n2: Prefix was not included.")
    def msg(m: str):
        '''Gives you a messagebox'''
        root = Tk()
        root.title = "%AdminCmd%"
        root.geometry("300x200") 
    
        messagebox.showinfo("%AdminCmd%", m)

        root.destroy()

def loop(startinputmsg: str="", error1msg: str="[Error]: Code 1", error2msg: str="[Error]: Code 2", noloop: bool=False, noloopdelay: int=1, cmddelay=0, exitcmd_enabled: bool=False, exitcmds: list=["quit","exit"], typeerrormsg: str="[Error]: "):
    '''Loop of the module.
    
    Note: Keep noloop arg to false if you want the user to be able to use commands over and over again!
    '''
    import time
    def cmd():
        cmd_input = input(startinputmsg)
        if not cmd_input.startswith(prefix):
            print(error2msg)
            return None, None
        parts = cmd_input[len(prefix):].split()
        if not parts:
            print(error2msg)
            return None, None
        return parts[0], parts[1:]

    while True:
        command, args = cmd()
        if command is not None:
            if command in exitcmds and exitcmd_enabled:
                break
            if command in cmds:
                try:
                    cmds[command](*args)
                    if noloop:
                        time.sleep(noloopdelay)
                        break
                    else:
                        time.sleep(cmddelay)
                except TypeError as e:
                    print(f"{typeerrormsg}{e}")
                    time.sleep(cmddelay)
            else:
                print(error1msg)
                time.sleep(cmddelay)

def startercmds():
    '''Adds 2 starter commands.
    List of cmds added:
        - help
        - errorinfo
    '''
    cmds['help'] = CMDS.helpc
    cmds['error'] = CMDS.errorinfo

def start(title:str="%ADMIN CMD%", vers: str="1.0"):
    '''Prints out info of the module'''
    print(title, vers)
    print("Prefix:",prefix)

def addcmd(cmdname: str=None):
    '''Decorator to add a command to the cmd list and returns a bool indicating if the action was successful.'''
    def decorator(function):
        nonlocal cmdname
        if cmdname is None:
            cmdname = function.__name__
        if cmdname and function:
            cmds[cmdname] = function
            return function  # Returning the original function, decoration successful
        else:
            raise ValueError("Command name and function must be provided")
    return decorator

def addcmd2(cmdname: str=None, func=None):
    '''The classic one, this is the non decorator version.'''
    if cmdname == None or func == None: raise ValueError("cmdname OR func was not provided.")
    cmds[cmdname] = func
    return cmds[cmdname]

if __name__ == "__main__": 
    c = CMDS()
    print(f"%ADMIN CMD% {c.vers}")
    print("Module Script. A example usage can be seen below:\n")
    print("Example code:\nimport admincmd\ndef x(): print('Example')\nadmincmd.cmds['example'] = x\nadmincmd.prefix = '>'\nadmincmd.startercmds()\nadmincmd.loop()")
    # print("\n\nPress enter to quit.")
    # input()
    print("Type any commands below.\nPrefix: %")
    startercmds()
    @addcmd()
    def moduleinfo():
        '''Gives you information of the module you're using.'''
        print("~!MODULE INFO!~\n")
        print("# What is admincmd?\nadmincmd is a easy module used to make like a command prompt application. There is absolutely, no limit.\n\n# How do I use admincmd?\nLet me give you a tutorial on how to use admincmd.")
        print("You can find info on how to use this module at the documentation.\nThat's all fellas!")
    loop()